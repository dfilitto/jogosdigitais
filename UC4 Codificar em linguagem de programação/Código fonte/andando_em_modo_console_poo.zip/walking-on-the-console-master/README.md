# walking-on-the-console
Introducing object-oriented programming
